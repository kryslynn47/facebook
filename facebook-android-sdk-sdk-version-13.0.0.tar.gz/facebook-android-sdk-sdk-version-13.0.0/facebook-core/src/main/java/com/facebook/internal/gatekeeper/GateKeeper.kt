package com.facebook.internal.gatekeeper

data class GateKeeper(val name: String, val value: Boolean)
